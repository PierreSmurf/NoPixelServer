fx_version 'adamant'
game 'common'

server_script 'yarn_builder.js'